module com.example.datastructure.chapter_04_{
	exports com.example.functional;
	requires com.example.datastructure.chapter_03_;
}
