package packt.java9.by.example.mybusiness.bulkorder;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfiguration {

}
