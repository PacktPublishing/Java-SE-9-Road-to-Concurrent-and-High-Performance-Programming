package packt.java9.by.example.mastermind;

public interface ColorFactory {
    Color newColor();
}
