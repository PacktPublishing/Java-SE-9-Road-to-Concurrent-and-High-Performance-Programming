//module packt.java9.by.example.ch03.quick{
//        exports packt.java9.by.example.ch03.quick;
//        requires packt.java9.by.example.ch03;
//        }